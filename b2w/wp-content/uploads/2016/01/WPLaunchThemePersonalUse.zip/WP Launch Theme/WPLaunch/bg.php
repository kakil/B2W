	<?php	if (get_option('inner-bg') == "1") {?>
	
			<style type='text/css'>
				#wrapper {
					background: url(<?php bloginfo("template_directory"); ?>/images/inner-bg.gif) repeat-x top #fff;
				}
			</style>
		
	<?php } ?>
	<?php	if (get_option('inner-bg') == "2") {?>
	
			<style type='text/css'>
				#wrapper {
					background: url(<?php bloginfo("template_directory"); ?>/images/inner-bg2.gif) repeat-x top #fff;
				}
			</style>
		
	<?php } ?>
	<?php	if (get_option('inner-bg') == "3") {?>
	
			<style type='text/css'>
				#wrapper {
					background: url(<?php bloginfo("template_directory"); ?>/images/inner-bg3.gif) repeat-x top #fff;
				}
			</style>
		
	<?php } ?>
	<?php	if (get_option('inner-bg') == "4") {?>
	
			<style type='text/css'>
				#wrapper {
					background: url(<?php bloginfo("template_directory"); ?>/images/inner-bg4.gif) repeat-x top #fff;
				}
			</style>
		
	<?php } ?>
	<?php	if (get_option('inner-bg') == "5") {?>
	
			<style type='text/css'>
				#wrapper {
					background: url(<?php bloginfo("template_directory"); ?>/images/inner-bg5.gif) repeat-x top #fff;
				}
				#logo h1 a {
					color: #333;
					text-shadow: 1px 1px 0 #fff;
				}
				#logo h3 {
					color: #666;
					text-shadow: 1px 1px 0 #fff;
				}
			</style>
		
	<?php } ?>
	<?php	if (get_option('inner-bg') == "6") {?>
	
			<style type='text/css'>
				#wrapper {
					background: url(<?php bloginfo("template_directory"); ?>/images/inner-bg6.gif) repeat-x top #fff;
				}
			</style>
		
	<?php } ?>
	<?php	if (get_option('inner-bg') == "7") {?>
	
			<style type='text/css'>
				#wrapper {
					background: url(<?php bloginfo("template_directory"); ?>/images/inner-bg7.gif) repeat-x top #fff;
				}
			</style>
		
	<?php } ?>
	<?php	if (get_option('inner-bg') == "8") {?>
	
			<style type='text/css'>
				#wrapper {
					background: url(<?php bloginfo("template_directory"); ?>/images/inner-bg8.gif) repeat-x top #fff;
				}
			</style>
		
	<?php } ?>
	<?php	if (get_option('inner-bg') == "9") {?>
	
			<style type='text/css'>
				#wrapper {
					background: url(<?php bloginfo("template_directory"); ?>/images/inner-bg9.gif) repeat-x top #fff;
				}
				#logo h1 a {
					color: #366a88;
					text-shadow: 1px 1px 0 #fff;
				}
				#logo h3 {
					color: #fff;
					text-shadow: 1px 1px 0 #639dbf;
				}
			</style>
		
	<?php } ?>
	<?php	if (get_option('inner-bg') == "10") {?>
	
			<style type='text/css'>
				#wrapper {
					background: url(<?php bloginfo("template_directory"); ?>/images/inner-bg10.gif) repeat-x top #fff;
				}
				#logo h1 a {
					color: #333;
					text-shadow: 1px 1px 0 #fff;
				}
				#logo h3 {
					color: #666;
					text-shadow: 1px 1px 0 #fff;
				}
			</style>
		
	<?php } ?>
	
	<?php	if (get_option('bg') == "1") {?>
	
			<style type='text/css'>
				body {
					background: url(<?php bloginfo("template_directory"); ?>/images/bg.gif) repeat-x top #282828;
				}
			</style>
		
	<?php } ?>
	<?php	if (get_option('bg') == "2") {?>
	
			<style type='text/css'>
				body {
					background: url(<?php bloginfo("template_directory"); ?>/images/bg2.gif) repeat-x top #282828;
				}
			</style>
		
	<?php } ?>
	<?php	if (get_option('bg') == "3") {?>
	
			<style type='text/css'>
				body {
					background: url(<?php bloginfo("template_directory"); ?>/images/bg3.gif) repeat-x top #282828;
				}
			</style>
		
	<?php } ?>
	<?php	if (get_option('bg') == "4") {?>
	
			<style type='text/css'>
				body {
					background: url(<?php bloginfo("template_directory"); ?>/images/bg4.gif) repeat-x top #282828;
				}
			</style>
		
	<?php } ?>
	<?php	if (get_option('bg') == "5") {?>
	
			<style type='text/css'>
				body {
					background: url(<?php bloginfo("template_directory"); ?>/images/bg5.gif) repeat-x top #282828;
				}
			</style>
		
	<?php } ?>
	
	
	<?php	if (get_option('type') == "1") {?>
	
			<style type='text/css'>
				body {
					font-family: Helvetica, Arial, Sans-serif;
				}
				p {
					font-size: 13px;
					font-style: italic;
					font-weight: normal;
					text-transform: normal;
					letter-spacing: normal;
					line-height: 1.6em;
					color: #444;
				}
			</style>
		
	<?php } ?>
	<?php	if (get_option('type') == "2") {?>
	
			<style type='text/css'>
				body {
					font-family: Verdana, Tahoma, Sans-serif;
				}
				p {
					font-size: 12px;
					font-style: normal;
					font-weight: normal;
					text-transform: normal;
					letter-spacing: normal;
					line-height: 1.6em;
					color: #444;
				}
				.readmore { font-size: 11px }
				.post .readmore { font-size: 11px }
				#info h2 {  font-size: 26px; letter-spacing: -2px }
				#sidebar h3 {  font-size: 16px; letter-spacing: -1px }
				div.column h3 {  font-size: 16px; letter-spacing: -1px }
				#content #posts div.post h2 a { letter-spacing: -2px; font-size: 24px; color: #333 }
				#navigation ul li a { font-size: 11px; letter-spacing: -1px }
			</style>
		
	<?php } ?>
	<?php	if (get_option('type') == "3") {?>
	
			<style type='text/css'>
				body {
					font-family: Cambria, Georgia, "New Times Roman", serif;
				}
				p {
					font-size: 13.5px;
					font-weight: normal;
					text-transform: normal;
					letter-spacing: normal;
					line-height: 1.5em;
					color: #555;
					padding: 5px 0;
				}
			</style>
		
	<?php } ?>
	
	
	<?php	if (get_option('icon') == "1") {?>
			<style type='text/css'>
				div.icon {
					background: url(<?php bloginfo("template_directory"); ?>/images/icon1.png) no-repeat left top;
				}
			</style>
	<?php } ?>
	<?php	if (get_option('icon') == "2") {?>
			<style type='text/css'>
				div.icon {
					background: url(<?php bloginfo("template_directory"); ?>/images/icon2.png) no-repeat left top;
				}
			</style>
	<?php } ?>
	<?php	if (get_option('icon') == "3") {?>
			<style type='text/css'>
				div.icon {
					background: url(<?php bloginfo("template_directory"); ?>/images/icon3.png) no-repeat left top;
				}
			</style>
	<?php } ?>
	<?php	if (get_option('icon') == "4") {?>
			<style type='text/css'>
				div.icon {
					background: url(<?php bloginfo("template_directory"); ?>/images/icon4.png) no-repeat left top;
				}
			</style>
	<?php } ?>
	<?php	if (get_option('icon') == "5") {?>
			<style type='text/css'>
				div.icon {
					background: url(<?php bloginfo("template_directory"); ?>/images/icon5.png) no-repeat left top;
				}
			</style>
	<?php } ?>
	<?php	if (get_option('icon') == "6") {?>
			<style type='text/css'>
				div.icon {
					background: url(<?php bloginfo("template_directory"); ?>/images/icon6.png) no-repeat left top;
				}
			</style>
	<?php } ?>
	<?php	if (get_option('icon') == "7") {?>
			<style type='text/css'>
				div.icon {
					background: url(<?php bloginfo("template_directory"); ?>/images/icon7.png) no-repeat left top;
				}
			</style>
	<?php } ?>
	<?php	if (get_option('icon') == "8") {?>
			<style type='text/css'>
				div.icon {
					background: url(<?php bloginfo("template_directory"); ?>/images/icon8.png) no-repeat left top;
				}
			</style>
	<?php } ?>
	<?php	if (get_option('icon') == "9") {?>
			<style type='text/css'>
				div.icon {
					background: url(<?php bloginfo("template_directory"); ?>/images/icon9.png) no-repeat left top;
				}
			</style>
	<?php } ?>
	<?php	if (get_option('icon') == "10") {?>
			<style type='text/css'>
				div.icon {
					background: url(<?php bloginfo("template_directory"); ?>/images/icon10.png) no-repeat left top;
				}
			</style>
	<?php } ?>
	
	<?php	if (get_option('calltoaction-graphic') == "1") {?>
			<style type='text/css'>
				#calltoaction {
					background: url(<?php bloginfo("template_directory"); ?>/images/pencircle.gif)  no-repeat top;
				}
			</style>
	<?php } ?>
	<?php	if (get_option('calltoaction-graphic') == "2") {?>
			<style type='text/css'>
				#calltoaction {
					background: url(<?php bloginfo("template_directory"); ?>/images/pencircle2.gif)  no-repeat top;
				}
			</style>
	<?php } ?>
	<?php	if (get_option('calltoaction-graphic') == "3") {?>
			<style type='text/css'>
				#calltoaction {
					background: url(<?php bloginfo("template_directory"); ?>/images/pencircle3.gif)  no-repeat top;
				}
			</style>
	<?php } ?>
	<?php	if (get_option('calltoaction-graphic') == "4") {?>
			<style type='text/css'>
				#calltoaction {
					background: url(<?php bloginfo("template_directory"); ?>/images/pencircle4.gif)  no-repeat top;
				}
			</style>
	<?php } ?>
	<?php	if (get_option('calltoaction-graphic') == "5") {?>
			<style type='text/css'>
				#calltoaction {
					background: url(<?php bloginfo("template_directory"); ?>/images/pencircle5.gif)  no-repeat top;
				}
			</style>
	<?php } ?>
	
	<!-- Banner Styles -->
	<?php	if (get_option('banner') == "1") {?>
	
			<style type='text/css'>
				#banner {
					background: #fff;
				}
			</style>
		
	<?php } ?>
	<?php	if (get_option('banner') == "2") {?>
	
			<style type='text/css'>
				#banner {
					background: url(<?php bloginfo("template_directory"); ?>/images/banner1.jpg) repeat top #fafafa;
				}
			</style>
		
	<?php } ?>
	<?php	if (get_option('banner') == "3") {?>
	
			<style type='text/css'>
				#banner {
					background: url(<?php bloginfo("template_directory"); ?>/images/banner2.jpg) repeat top #fafafa;
				}
				#info h2 {
					color: #fff;
					text-shadow: 1px 1px 0 #222;
				}
				#info p {
					color: #fff;
					text-shadow: 1px 1px 0 #222;
				}
			</style>
		
	<?php } ?>
	<?php	if (get_option('banner') == "4") {?>
	
			<style type='text/css'>
				#banner {
					background: url(<?php bloginfo("template_directory"); ?>/images/banner3.jpg) repeat top #fafafa;
				}
				#info h2 {
					color: #fff;
					text-shadow: 1px 1px 0 #222;
				}
				#info p {
					color: #fff;
					text-shadow: 1px 1px 0 #222;
				}
			</style>
		
	<?php } ?>
	<?php	if (get_option('banner') == "5") {?>
	
			<style type='text/css'>
				#banner {
					background: url(<?php bloginfo("template_directory"); ?>/images/banner4.jpg) repeat top #fafafa;
				}
				#info h2 {
					color: #fff;
					text-shadow: 1px 1px 0 #222;
				}
				#info p {
					color: #fff;
					text-shadow: 1px 1px 0 #222;
				}
			</style>
		
	<?php } ?>
	<?php	if (get_option('banner') == "6") {?>
	
			<style type='text/css'>
				#banner {
					background: url(<?php bloginfo("template_directory"); ?>/images/banner5.jpg) repeat top #fafafa;
				}
				#info h2 {
					color: #fff;
					text-shadow: 1px 1px 0 #222;
				}
				#info p {
					color: #fff;
					text-shadow: 1px 1px 0 #222;
				}
			</style>
		
	<?php } ?>
	<?php	if (get_option('banner') == "7") {?>
	
			<style type='text/css'>
				#banner {
					background: url(<?php bloginfo("template_directory"); ?>/images/banner6.jpg) repeat top #fafafa;
				}
				#info h2 {
					color: #fff;
					text-shadow: 1px 1px 0 #222;
				}
				#info p {
					color: #fff;
					text-shadow: 1px 1px 0 #222;
				}
			</style>
		
	<?php } ?>
		
	<?php	if (get_option('banner') == "8") {?>
	
			<style type='text/css'>
				#banner {
					background: url(<?php bloginfo("template_directory"); ?>/images/banner7.jpg) repeat top #fafafa;
				}
				#info h2 {
					color: #fff;
					text-shadow: 1px 1px 0 #222;
				}
				#info p {
					color: #fff;
					text-shadow: 1px 1px 0 #222;
				}
			</style>
		
	<?php } ?>
	<?php	if (get_option('banner') == "9") {?>
	
			<style type='text/css'>
				#banner {
					background: url(<?php bloginfo("template_directory"); ?>/images/banner8.jpg) repeat top #fafafa;
				}
				#info h2 {
					color: #fff;
					text-shadow: 1px 1px 0 #222;
				}
				#info p {
					color: #fff;
					text-shadow: 1px 1px 0 #222;
				}
			</style>
		
	<?php } ?>
	<?php	if (get_option('banner') == "10") {?>
	
			<style type='text/css'>
				#banner {
					background: url(<?php bloginfo("template_directory"); ?>/images/banner9.jpg) repeat top #fafafa;
				}
			</style>
		
	<?php } ?>
	<?php	if (get_option('banner') == "11") {?>
	
			<style type='text/css'>
				#banner {
					background: url(<?php bloginfo("template_directory"); ?>/images/banner10.jpg) repeat top #fafafa;
				}
				#info h2 {
					color: #fff;
					text-shadow: 1px 1px 0 #222;
				}
				#info p {
					color: #fff;
					text-shadow: 1px 1px 0 #222;
				}
			</style>
		
	<?php } ?>
	
	
	<?php	if (get_option('optin-pop') == "1") {?>
	
			<style type='text/css'>
				#optinPopup {
					background: url(<?php bloginfo("template_directory"); ?>/images/popup1.png) repeat top;
				}
			</style>
		
	<?php } ?>
	<?php	if (get_option('optin-pop') == "2") {?>
	
			<style type='text/css'>
				#optinPopup {
					background: url(<?php bloginfo("template_directory"); ?>/images/popup2.png) repeat top;
				}
				#optinPopup h2.title {
					color: #fff;
					text-shadow: 1px 1px 0 #000;	
				}
			</style>
		
	<?php } ?>
	<?php	if (get_option('optin-pop') == "3") {?>
	
			<style type='text/css'>
				#optinPopup {
					background: url(<?php bloginfo("template_directory"); ?>/images/popup3.png) repeat top;
				}
				#optinPopup h2.title {
					color: #fff;
					text-shadow: 1px 1px 0 #000;	
				}
			</style>
		
	<?php } ?>
	<?php	if (get_option('optin-pop') == "4") {?>
	
			<style type='text/css'>
				#optinPopup {
					background: url(<?php bloginfo("template_directory"); ?>/images/popup4.png) repeat top;
				}
				#optinPopup h2.title {
					color: #fff;
					text-shadow: 1px 1px 0 #000;	
				}
			</style>
		
	<?php } ?>
	<?php	if (get_option('optin-pop') == "5") {?>
	
			<style type='text/css'>
				#optinPopup {
					background: url(<?php bloginfo("template_directory"); ?>/images/popup5.png) repeat top;
				}
				#optinPopup h2.title {
					color: #fff;
					text-shadow: 1px 1px 0 #000;	
				}
			</style>
		
	<?php } ?>