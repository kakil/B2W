Thank you for your purchase.

You can watch video here for help:

http://screenr.com/ufa