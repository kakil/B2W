Thank you for your PLR Purchase.

This folder includes the source for the sales page and wordpress theme.

You can resell the wordpress theme to your customers, and edit any pages or all.

The license is included.